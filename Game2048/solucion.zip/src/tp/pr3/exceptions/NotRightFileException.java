package tp.pr3.exceptions;

public class NotRightFileException extends Exception{
	public NotRightFileException(String text) {
		super(text);
	}
}
