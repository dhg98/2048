package tp.pr3.exceptions;

public class BoardSizeException extends Exception{
	public BoardSizeException(String text){
		super(text);
	}
}
