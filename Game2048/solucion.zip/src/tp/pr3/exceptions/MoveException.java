package tp.pr3.exceptions;

public class MoveException extends Exception{

	public MoveException (String text) {
		super(text);
	}
}
