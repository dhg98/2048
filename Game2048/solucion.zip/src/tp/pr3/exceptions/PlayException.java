package tp.pr3.exceptions;

public class PlayException extends Exception {
	public PlayException(String text) {
		super(text);
	}
}
