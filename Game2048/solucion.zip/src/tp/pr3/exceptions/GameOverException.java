package tp.pr3.exceptions;

public class GameOverException extends Exception{
	public GameOverException(String text){
		super(text);
	}
}