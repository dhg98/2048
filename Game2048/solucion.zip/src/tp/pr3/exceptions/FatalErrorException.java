package tp.pr3.exceptions;

public class FatalErrorException extends Exception{
	public FatalErrorException(String text){
		super(text);
	}
}
