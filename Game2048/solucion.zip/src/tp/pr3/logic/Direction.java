package tp.pr3.logic;

public enum Direction {
	UP, DOWN, LEFT, RIGHT;
	
}
