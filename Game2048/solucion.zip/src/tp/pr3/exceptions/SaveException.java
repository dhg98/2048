package tp.pr3.exceptions;

public class SaveException extends Exception {

	public SaveException (String text) {
		super(text);
	}
}
