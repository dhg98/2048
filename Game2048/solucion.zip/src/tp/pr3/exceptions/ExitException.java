package tp.pr3.exceptions;

public class ExitException extends Exception{
	public ExitException(){
		super();
	}
}