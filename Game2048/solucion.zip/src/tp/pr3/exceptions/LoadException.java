package tp.pr3.exceptions;

public class LoadException extends Exception{

	public LoadException (String text) {
		super(text);
	}
}
