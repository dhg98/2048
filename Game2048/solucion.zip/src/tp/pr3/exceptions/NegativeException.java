package tp.pr3.exceptions;

public class NegativeException extends Exception{
	public NegativeException (String text) {
		super(text);
	}
}
